package com.example.rec

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import androidx.constraintlayout.widget.ConstraintLayout
import androidx.recyclerview.widget.LinearLayoutManager
import kotlinx.android.synthetic.main.activity_main.*

class MainActivity : AppCompatActivity() {
    private lateinit var clroot: ConstraintLayout
    private lateinit var name: EditText
    private lateinit var btn: Button
    private lateinit var messages: ArrayList<String>

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        clroot = findViewById(R.id.clroot)
        messages = ArrayList()

        recyclerV.adapter = MainActivity2(this, messages)
        recyclerV.layoutManager = LinearLayoutManager(this)

        name = findViewById(R.id.name)
        btn = findViewById(R.id.btn)

        btn.setOnClickListener { addMessage() }

    }
    private fun addMessage(){
        val msg = name.text.toString()
        if(msg.isNotEmpty()){
            messages.add(msg)
            name.text.clear()
            name.clearFocus()
        }
    }


}